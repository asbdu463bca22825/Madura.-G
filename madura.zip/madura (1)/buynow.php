<?php
session_start();

$products = [
    1 => ["name"=>"Mobile", "price"=>15000, "image"=>"images/mobile.jpeg"],
    2 => ["name"=>"Laptop", "price"=>45000, "image"=>"images/laptop.jpeg"],
    3 => ["name"=>"Headphone", "price"=>10000, "image"=>"images/headphone.jpeg"]
    
  
    
];

$id = $_GET['id'] ?? 0;

if (!isset($products[$id])) {
    die("Invalid Product");
}

$product = $products[$id];

$qty = 1;
$total = $product['price'] * $qty;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Buy Now</title>

    <style>
        body{
            font-family: Arial;
            background:#f2f2f2;
            margin:0;
        }

        .container{
            width:400px;
            margin:80px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px #ccc;
            text-align:center;
        }

        img{
            width:200px;
            height:200px;
            border-radius:10px;
        }

        h2{
            margin:10px 0;
        }

        .price{
            color:green;
            font-size:18px;
            font-weight:bold;
        }

        input{
            width:60px;
            padding:5px;
            text-align:center;
            margin:10px 0;
        }

        .btn{
            display:block;
            background:#28a745;
            color:white;
            padding:10px;
            text-decoration:none;
            margin-top:10px;
            border-radius:5px;
        }

        .btn:hover{
            background:#218838;
        }

        .back{
            background:#ff9f00;
        }

        .back:hover{
            background:#fb8c00;
        }
    </style>
</head>

<body>

<div class="container">

    <img src="<?php echo $product['image']; ?>">

    <h2><?php echo $product['name']; ?></h2>

    <p class="price">₹<?php echo $product['price']; ?></p>

    <form method="post">
        <label>Quantity:</label><br>

        <input type="number" name="qty" value="1" min="1">

        <p><b>Total: ₹<?php echo $total; ?></b></p>
        <a href="placeorder.php?id=3" class="btn">place order</a>

    </form>

    <a href="home.php" class="btn back">Back to Shop</a>

</div>

</body>
</html>
