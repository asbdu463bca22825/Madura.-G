
<?php
session_start();

$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <style>
        body{
            font-family: Arial;
        }

        table{
            width:80%;
            margin:auto;
            border-collapse:collapse;
            background:white;
        }

        th,td{
            border:1px solid #ddd;
            padding:10px;
            text-align:center;
        }

        img{
            width:60px;
        }

        .empty{
            text-align:center;
            margin-top:50px;
            font-size:20px;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">🛒 Your Cart</h2>

<?php if(empty($cart)) { ?>

    <p class="empty">Your cart is empty 🛒</p>

<?php } else { ?>

<table>
    <tr>
        <th>Image</th>
        <th>Name</th>
        <th>Price</th>
        <th>Qty</th>
        <th>Subtotal</th>
        <th>Action</th>
        <th>order</th>
    </tr>

    <?php foreach($cart as $id => $item): 

        $subtotal = $item['price'] * $item['qty'];
        $total += $subtotal;
    ?>

    <tr>
        <td><img src="<?php echo $item['image']; ?>"></td>
        <td><?php echo $item['name']; ?></td>
        <td>₹<?php echo $item['price']; ?></td>
        <td><?php echo $item['qty']; ?></td>
        <td>₹<?php echo $subtotal; ?></td>
        <td>
    <a href="remove.php?id=<?php echo $id; ?>">Remove</a> |
    <a href="home.php">Back</a>
</td>

<td>
    <a href="buynow.php?id=<?php echo $id; ?>">Buy Now</a>
</td>
    </tr>

    <?php endforeach; ?>

    <tr>
        <td colspan="5"><b>Total</b></td>
        <td colspan="2"><b>₹<?php echo $total; ?></b></td>
    </tr>
</table>

<?php } ?>

</body>
</html>
