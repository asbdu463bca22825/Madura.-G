<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>E-Commerce Home</title>

    <style>
        body{
            font-family: Arial;
            background:#f4f4f4;
            margin:0;
        }

        .header{
            background:#333;
            color:white;
            padding:15px;
            display:flex;
            justify-content:space-between;
        }

        .products{
            display:grid;
            grid-template-columns:repeat(3,1fr);
            gap:20px;
            padding:20px;
        }

        .card{
            background:white;
            padding:15px;
            border-radius:10px;
            box-shadow:0 0 5px #ccc;
            text-align:center;
        }

        .card img{
            width:200px;
            height:200px;
        }

        .btn {
            display:inline-block;
            margin-top:10px;
            padding:10px;
            background:#ff9f00;
            color:white;
            text-decoration:none;
            border-radius:5px;
        }

        .btn:hover{
            background:#fb8c00;
        }
    </style>
</head>

<body>

<div class="header">
    <h2>Online Shop</h2>
    <h3>Welcome <?php echo $_SESSION['user']; ?></h3>
</div>

<div class="products">

    <!-- MOBILE -->
    <div class="card">
        <img src="images/mobile.jpeg">
        <h3>Mobile</h3>
        <p>₹15,000</p>

        <a href="buynow.php?id=1" class="btn">Buy Now</a>
        <a href="cart_action.php?id=1" class="btn">Add to Cart</a>
    </div>

    <!-- LAPTOP -->
    <div class="card">
        <img src="images/laptop.jpeg">
        <h3>Laptop</h3>
        <p>₹45,000</p>

        <a href="buynow.php?id=2" class="btn">Buy Now</a>
        <a href="cart_action.php?id=2" class="btn">Add to Cart</a>
    </div>

    <!-- HEADPHONE -->
    <div class="card">
        <img src="images/headphone.jpeg">
        <h3>Headphone</h3>
        <p>₹10,000</p>

        <a href="buynow.php?id=3" class="btn">Buy Now</a>
        <a href="cart_action.php?id=3" class="btn">Add to Cart</a>
    </div>

</div>

</body>
</html>
