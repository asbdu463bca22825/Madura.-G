<?php
session_start();

$products = [
    1 => [
        "name" => "Mobile",
        "price" => 15000,
        "image" => "images/mobile.jpeg"
    ],
    2 => [
        "name" => "Laptop",
        "price" => 45000,
        "image" => "images/laptop.jpeg"
    ],
    3 => [
        "name" => "Headphone",
        "price" => 10000,
        "image" => "images/headphone.jpeg"
    ]
];

$id = $_GET['id'];

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($products[$id])) {

    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]['qty']++;
    } else {
        $_SESSION['cart'][$id] = [
            "name"  => $products[$id]['name'],
            "price" => $products[$id]['price'],
            "image" => $products[$id]['image'],
            "qty"   => 1
        ];
    }
}

header("Location: cart.php");
exit();
?>
