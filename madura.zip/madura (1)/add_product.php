<?php
include "database.php";

if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $price = $_POST['price'];
    $desc = $_POST['description'];

    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    $folder = "uploads/" . $image;

    if(move_uploaded_file($tmp, $folder)){

        $sql = "INSERT INTO product(name, price, image, description)
                VALUES('$name','$price','$folder','$desc')";

        $conn->query($sql);

        echo "<script>alert('Product Added');</script>";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <h2>Add Product</h2>

    <input type="text" name="name" placeholder="Product Name"><br><br>

    <input type="number" name="price" placeholder="Price"><br><br>

    <textarea name="description" placeholder="Description"></textarea><br><br>

    <input type="file" name="image"><br><br>

    <button type="submit" name="submit">Add Product</button>
</form>
