<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>

    <style>
        body{
            font-family: Arial;
            background:#f4f4f4;
            margin:0;
        }

        .header{
            background:#222;
            color:white;
            padding:15px;
            display:flex;
            justify-content:space-between;
            align-items:center;
        }

        .container{
            padding:20px;
        }

        .grid{
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));
            gap:20px;
        }

        .card{
            background:white;
            border-radius:12px;
            padding:15px;
            text-align:center;
            box-shadow:0 4px 10px rgba(0,0,0,0.1);
            transition:0.3s;
        }

        .card:hover{
            transform:translateY(-5px);
        }

        .card img{
            width:140px;
            height:140px;
            object-fit:cover;
        }

        .btn{
            display:inline-block;
            margin-top:10px;
            padding:10px;
            border-radius:6px;
            text-decoration:none;
            color:white;
        }

        .buy{
            background:#ff9800;
        }

        .cart{
            background:#4caf50;
        }

        .btn:hover{
            opacity:0.9;
        }
    </style>
</head>

<body>

<div class="header">
    <h2>🛒 Products</h2>
    <div>Welcome, <?php echo $_SESSION['user']; ?></div>
</div>

<div class="container">

<div class="grid">

<?php
$products = [
    ["id"=>1, "name"=>"Mobile", "price"=>"₹15,000", "img"=>"mobile.jpeg"],
    ["id"=>2, "name"=>"Laptop", "price"=>"₹45,000", "img"=>"laptop.jpeg"],
    ["id"=>3, "name"=>"Headphone", "price"=>"₹10,000", "img"=>"headphone.jpeg"],
    
foreach($products as $p){
?>

    <div class="card">
        <img src="images/<?php echo $p['img']; ?>">
        <h3><?php echo $p['name']; ?></h3>
        <p><b><?php echo $p['price']; ?></b></p>

        <a class="btn buy" href="buynow.php?id=<?php echo $p['id']; ?>">Buy Now</a>
        <a class="btn cart" href="add_card.php?id=<?php echo $p['id']; ?>">Add to Cart</a>
    </div>

<?php } ?>

</div>

</div>

</body>
</html>
