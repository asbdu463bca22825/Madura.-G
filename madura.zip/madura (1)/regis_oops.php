<?php
class User {

    private $conn;

   
    public function __construct($conn) {
        $this->conn = $conn;
    }

    
    public function register($name, $email, $password, $phonenum) {

        $name = trim($name);
        $email = trim($email);
        $phonenum = trim($phonenum);

      
        if(empty($name) || empty($email) || empty($password) || empty($phonenum)){
            return "Please fill all fields";
        }

        $sql = "SELECT * FROM user WHERE email='$email'";
        $result = $this->conn->query($sql);

        if($result->num_rows > 0){
            return "Email already registered";
        }


        $password = password_hash($password, PASSWORD_DEFAULT);

        $insert = "INSERT INTO user(name, email, password, phonenum)
                   VALUES('$name', '$email', '$password', '$phonenum')";

        if($conn->query($sql)){
        echo "<script>
                alert('Registration Successful');
                window.location='login.php';
              </script>";
    } 
    else
     {
        echo "Error: " . $conn->error;
    }
}
header("loaction:login.php")
exit()
?>
