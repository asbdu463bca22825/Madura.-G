<?php

session_start();

session_destroy();

header("Location:login.php");

?>


<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
   <style>
    
body{

    font-family: Arial;
    background-color: #1b1b32;;
}
form{
    width:400px;
    margin:100px auto;
    padding:20px;
    background-color: rgb(240, 242, 245);
    border-radius: 10px;
}
input{
    width:90%;
    padding: 10px;
    margin:8px auto;
}
button{
    width:90%;
    padding:10px;
    background-color: whit;
    color: aqua;
    border:non;


}
h1{
    text-align: center;
    background-color:rgb(240, 242, 245);
 
    

}
  
 </style>

</head>

<body>



<form id="logoutForm">
	<h2>Logout Page</h2>

<input type="email" id="email" placeholder="Enter Email"><br><br>

<input type="password" id="password" placeholder="Enter Password"><br><br>

<button type="submit">Logout</button>

</form>
