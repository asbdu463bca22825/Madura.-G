<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Place Order & Payment</title>

    <style>
        body{
            font-family:Arial;
            background:#f2f2f2;
        }

        .box{
            width:420px;
            margin:50px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px #ccc;
        }

        input, textarea, select{
            width:90%;
            padding:10px;
            margin:10px 0;
        }

        button{
            width:100%;
            padding:10px;
            background:green;
            color:white;
            border:none;
            cursor:pointer;
        }

        h2{
            text-align:center;
        }
    </style>
</head>

<body>

<div class="box">

    <h2>Place Order</h2>

    <form method="post" action="success.php">

        <input type="text" name="name" placeholder="Enter Name" required>

        <input type="text" name="phone" placeholder="Enter Phone" required>

        <textarea name="address" placeholder="Enter Address" required></textarea>

        <input type="text" name="city" placeholder="Enter City" required>

        <input type="text" name="country" placeholder="Enter Country" required>

        <input type="text" name="pincode" placeholder="Enter Pincode" required>

        <select name="payment" required>
            <option value="">Select Payment Method</option>
            <option value="COD">Cash on Delivery</option>
            <option value="UPI">UPI Payment</option>
            <option value="CARD">Debit/Credit Card</option>
        </select>
        <button type="submit">Confirm Order</button>
    </form>

</div>

</body>
</html>
