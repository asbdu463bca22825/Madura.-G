
<?php

session_start();

include "database.php";
include "user_update.php";

$db = new Database();
$conn = $db->connect();

$user = new User($conn);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;


$row = $user->getUserById($id);

if(!$row){
    echo "User Not Found";
    exit();
}


if(isset($_POST['update'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phonenum = $_POST['phonenum'];

    $result = $user->updateUser($id, $name, $email, $password, $phonenum);

    if($result === "success"){
        header("Location: view_table.php");
        exit();
    } else {
        echo $result;
    }
}

?>

<form method="POST">

<input type="text" name="name"
value="<?php echo $row['name']; ?>"><br><br>

<input type="email" name="email"
value="<?php echo $row['email']; ?>"><br><br>

<input type="password" name="password"
value="<?php echo $row['password']; ?>"><br><br>

<input type="tel" name="phonenum"
value="<?php echo $row['phonenum']; ?>"><br><br>

<button type="submit" name="update">Update</button>

</form>
