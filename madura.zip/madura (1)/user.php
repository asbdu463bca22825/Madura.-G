<?php

class User {

    private $conn;

    public function __construct($db){
        $this->conn = $db;
    }

    public function login($email, $password){

        if(empty($email) || empty($password)){
            return "Please fill all fields";
        }

        $sql = "SELECT * FROM user WHERE email='$email'";
        $result = $this->conn->query($sql);

        if($result->num_rows > 0){

            $row = $result->fetch_assoc();

            if(password_verify($password, $row['password'])){

                $_SESSION['user'] = $row['name'];

                return "success";

            } else {
                return "Invalid Password";
            }

        } else {
            return "Email not found";
        }
    }
}
?>
