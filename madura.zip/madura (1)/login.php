<?php
session_start();
include "database.php";

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email) || empty($password)) 
    {
        echo "Please fill all fields";
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();

        if (password_verify($password, $row['password'])) {

            $_SESSION['user'] = $row['name'];

            echo "success";

        } else {
            echo "Invalid Password";
        }

    } else {
        echo "Email not found";
    }

    exit();
}

session_destroy();
?>


<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
   <style>
    
body{

    font-family: Arial;
    background-color: #1b1b32;;
}
form{
    width:400px;
    margin:100px auto;
    padding:20px;
    background-color: rgb(240, 242, 245);
    border-radius: 10px;
}
input{
    width:90%;
    padding: 10px;
    margin:8px auto;
}
button{
    width:90%;
    padding:10px;
    background-color: whit;
    color: aqua;
    border:non;


}
h1{
    text-align: center;
    background-color:rgb(240, 242, 245);
 
    

}
  
 </style>

</head>

<body>



<form id="loginForm">
	<h2>Login Page</h2>

<input type="email" id="email" placeholder="Enter Email"><br><br>

<input type="password" id="password" placeholder="Enter Password"><br><br>

<button type="submit">Login</button>

</form>

<h3 id="result"></h3>

<script>

$(document).ready(function(){

    $("#loginForm").submit(function(e){

        e.preventDefault();

        var email = $("#email").val();
        var password = $("#password").val();

        $.ajax({

            url:"login.php",
            type:"POST",

            data:{
                login:true,
                email:email,
                password:password
            },

            success:function(response){

                if(response == "success"){

                    window.location="home.php";

                }

                else{

                    $("#result").html(response);

                }

            }

        });

    });

});

</script>

</body>
</html>

