<?php
session_start();

if(!isset($_SESSION['user'])){
    header("Location:login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
     <style>
    
body{

    font-family: Arial;
    background-color: rgb(240, 242, 245);
}
form{
    width:300px;
    margin:100px auto;
    padding:20px;
    background-color: rgb(240, 242, 245);
    border-radius: 10px;
}
input{
    width:90%;
    padding: 10px;
    margin:8px auto;
}
button{
    width:100%;
    padding:10px;
    background-color: whit;
    color: aqua;
    border:non;


}
h1{
    text-align: center;
    background-color:rgb(240, 242, 245);
 
    

}
  
</style>
</head>
<body>

<h1>
 Your login successful Welcome
<?php echo $_SESSION['user']; ?>
</h1>

<a href="view_table.php">View Users</a><br><br>

<a href="logout.php">Logout</a>

</body>
</html>
